async function getData(){
    input = document.getElementById("timesinput").value
    input = input.toString()
    input = input.split("\n")
    let times = []
    input.map((time) => {
        [nome, estado] = time.split(";")
        times.push({nome:nome, estado:estado, pontos:0})
    })
    let jogosDeIda=[] 
    jogosDeIda = arranjaJogadasIda(times)
    let jogosDeVolta=[]
    jogosDeVolta = arranjaJogadasVolta(times)
    
    console.log('Todos os Times')
    console.log(times)
    console.log('\n-----------------\n')
    console.log('Todos os possiveis jogos')
    console.log('1° Turno')
    console.log(jogosDeIda)
    console.log('2° Turno')
    console.log(jogosDeVolta)
    console.log('\n-----------------\n')
    console.log(gerarRodadas(jogosDeIda))
}
/*function gerarRodadas(jogos){
    let rodadas = []
    for (let index = 0; 0 <= jogos.length; index++) {
        let rodada = []
        jogos.forEach(jogo => {
            let flag = true
            rodada.forEach(element => {
                if(element.timeA == jogo.timeA || element.timeA ==jogo.timeB || element.timeB == jogo.timeA || element.timeB ==jogo.timeB){
                    flag = false
                }
                
            });
            if (flag) {
                rodada.push(jogo)
                arrayRemove(jogos, jogo)
            }
        });
        rodadas.push(rodada)
        
    }
    return rodadas
}*/
function gerarRodadas(jogos){
    let rodadas = []
    
        let rodada = []
        jogos.forEach(jogo => {
            let flag = true
            rodada.forEach(element => {
                if(element.timeA == jogo.timeA || element.timeA ==jogo.timeB || element.timeB == jogo.timeA || element.timeB ==jogo.timeB){
                    flag = false
                }
                
            });
            if (flag) {
                rodada.push(jogo)
                arrayRemove(jogos, jogo)
            }
        });
        rodadas.push(rodada)
        
    
    return rodadas
}

function arranjaJogadasIda(times) {
    let jogadas = []
    
    times.map((timeA) => {
        times.map((timeB) => {
            if(timeA != timeB) 
                jogadas.push({timeA:timeA, timeB:timeB, val:''})
        })
        times = arrayRemove(times, timeA)
    })

    return jogadas
}
function arranjaJogadasVolta(times) {
    let jogadas = []
    
    times.map((timeA) => {
        times.map((timeB) => {
            if(timeA != timeB) 
                jogadas.push({timeA:timeB, timeB:timeA, val:''})
        })
        times = arrayRemove(times, timeA)
    })

    return jogadas
}

function arrayRemove(arr, value) { 
    
    return arr.filter(function(ele){ 
        return ele != value; 
    });
}
function getRandomInt(min, max) {
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min)) + min;
}
